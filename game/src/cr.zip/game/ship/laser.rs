use bevy::prelude::*;

const LASER_VELOCITY: f32 = 480.0; // pixels per second

#[derive(Component)]
pub struct Laser;

impl Laser {
    /// Update the laser's position according to the frame delta time
    fn update_position(&mut self, dt: f32, pos: &mut Vec3) {
        pos.y += LASER_VELOCITY * dt;
    }

    /// Despawn the laser if it goes off the top of the screen
    fn despawn_if_needed(&self, pos: &mut Vec3, commands: &mut Commands, entity: Entity) {
        if pos.y > 240.0 {
            commands.entity(entity).despawn();
        }
    }
}

pub fn movement(
    time: Res<Time>,
    mut query: Query<(Entity, &mut Laser, &mut Transform)>,
    mut commands: Commands,
) {
    let dt = time.delta_seconds();
    for (entity, mut laser, mut trans) in query.iter_mut() {
        let pos = &mut trans.translation;
        laser.update_position(dt, pos);
        laser.despawn_if_needed(pos, &mut commands, entity)
    }
}
